# LL & K — prezentāciju vietne

Vienas lapas Next.js vietne ar LV / ENG / RU valodas pārslēdzēju un trim prezentācijas sadaļu kartītēm. Katra kartīte atver attiecīgās valodas PDF konkrētajā lapā; atsevišķi pieejama visas prezentācijas lejupielāde.

## Lokāla palaišana

Nepieciešams Node.js 20.9 vai jaunāks.

```bash
npm install
npm run dev
```

Atveriet http://localhost:3000.

## Publicēšana GitHub + Vercel

1. Izveidojiet jaunu GitHub repozitoriju, piemēram, `llk-presentaciju-vietne`.
2. Augšupielādējiet šī projekta mapes saturu repozitorijā (nevis pašu ZIP failu).
3. Vercel izvēlieties **Add New → Project**, pieslēdziet GitHub un importējiet šo repozitoriju.
4. Framework preset: **Next.js**; pārējās būvēšanas vērtības atstājiet noklusētās.
5. Spiediet **Deploy**. Vercel piešķirs pagaidu adresi `*.vercel.app`.

## PDF faili

PDF faili jau atrodas `public/presentations/`:
- `llk-lv.pdf` — latviešu valoda
- `llk-en.pdf` — angļu valoda
- `llk-ru.pdf` — krievu valoda

Kartīšu saites atver attiecīgi 1., 7. vai 13. PDF lapu. Ja nākotnē mainās PDF lapu numerācija, atjauniniet `page` vērtības `src/app/page.tsx`.

## Dizains

Tumši zaļš, silti balts/smilškrāsas un zelta akcenti. Galvenā fotogrāfija `public/hero.jpg` izveidota no latviešu PDF pirmās lapas attēla zonas.
