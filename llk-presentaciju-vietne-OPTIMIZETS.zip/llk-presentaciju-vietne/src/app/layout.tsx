import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'LL & K — Jūsu māja. Mūsu atbildība.',
  description: 'LL & K māju apsaimniekošanas piedāvājumi, pieredze un komanda. Pieejams latviešu, angļu un krievu valodā.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="lv"><body>{children}</body></html>;
}
