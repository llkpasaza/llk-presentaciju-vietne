'use client';

import { useState } from 'react';

type Language = 'LV' | 'ENG' | 'RU';

type Copy = {
  eyebrow: string;
  headlineA: string;
  headlineB: string;
  intro: string;
  choose: string;
  cards: { number: string; title: string; description: string; action: string; page: number }[];
  download: string;
  footer: string;
  contact: string;
};

const copy: Record<Language, Copy> = {
  LV: {
    eyebrow: 'SIA “LL & K” · MĀJU APSAIMNIEKOŠANA',
    headlineA: 'Jūsu māja.', headlineB: 'Mūsu atbildība.',
    intro: 'Sakārtota vide. Skaidra pārvaldība. Ilgtermiņa plāns.',
    choose: 'Izvēlieties prezentācijas sadaļu',
    cards: [
      { number: '01', title: 'Konkrēts piedāvājums', description: 'Mājas vajadzības, apsaimniekošanas pieeja un izmaksu sadalījums.', action: 'Atvērt piedāvājumu', page: 1 },
      { number: '02', title: 'Mūsu pieredze', description: 'Paveiktie darbi un piemēri, ko iespējams apskatīt klātienē.', action: 'Apskatīt paveikto', page: 7 },
      { number: '03', title: 'Mūsu komanda un pieeja', description: 'Ikdienas darbs, atbildība un pirmie soļi sadarbībā.', action: 'Iepazīt mūsu pieeju', page: 13 },
    ],
    download: 'Lejupielādēt visu prezentāciju (PDF)',
    footer: 'Sakārtota vide · Skaidra pārvaldība · Ilgtermiņa plāns',
    contact: 'Sazināties ar LL & K',
  },
  ENG: {
    eyebrow: 'SIA “LL & K” · PROPERTY MANAGEMENT',
    headlineA: 'Your home.', headlineB: 'Our responsibility.',
    intro: 'Well-kept surroundings. Clear management. A long-term plan.',
    choose: 'Choose a presentation section',
    cards: [
      { number: '01', title: 'A concrete proposal', description: 'Your building’s needs, our management approach and cost breakdown.', action: 'Open the proposal', page: 1 },
      { number: '02', title: 'Our experience', description: 'Completed work and examples you can see in person.', action: 'Explore our work', page: 7 },
      { number: '03', title: 'Our team and approach', description: 'Daily work, accountability and the first steps towards cooperation.', action: 'Meet our approach', page: 13 },
    ],
    download: 'Download the full presentation (PDF)',
    footer: 'Well-kept surroundings · Clear management · Long-term plan',
    contact: 'Contact LL & K',
  },
  RU: {
    eyebrow: 'SIA «LL & K» · УПРАВЛЕНИЕ НЕДВИЖИМОСТЬЮ',
    headlineA: 'Ваш дом.', headlineB: 'Наша ответственность.',
    intro: 'Ухоженная среда. Понятное управление. Долгосрочный план.',
    choose: 'Выберите раздел презентации',
    cards: [
      { number: '01', title: 'Конкретное предложение', description: 'Потребности дома, наш подход к управлению и структура расходов.', action: 'Открыть предложение', page: 1 },
      { number: '02', title: 'Наш опыт', description: 'Выполненные работы и примеры, которые можно увидеть на месте.', action: 'Посмотреть результаты', page: 7 },
      { number: '03', title: 'Наша команда и подход', description: 'Ежедневная работа, ответственность и первые шаги сотрудничества.', action: 'Познакомиться с подходом', page: 13 },
    ],
    download: 'Скачать полную презентацию (PDF)',
    footer: 'Ухоженная среда · Понятное управление · Долгосрочный план',
    contact: 'Связаться с LL & K',
  },
};

const pdfs: Record<Language, string> = {
  LV: '/presentations/llk-lv.pdf',
  ENG: '/presentations/llk-en.pdf',
  RU: '/presentations/llk-ru.pdf',
};

export default function Home() {
  const [language, setLanguage] = useState<Language>('LV');
  const t = copy[language];

  return (
    <main className="site-shell">
      <header className="topbar">
        <a className="brand" href="#top" aria-label="LL & K sākums">
          <span className="brand-mark">LL <i>&</i> K</span>
          <span className="brand-caption">PROPERTY MANAGEMENT</span>
        </a>
        <nav className="language-switch" aria-label="Choose language">
          {(['LV', 'ENG', 'RU'] as Language[]).map((lang) => (
            <button key={lang} className={language === lang ? 'language active' : 'language'} onClick={() => setLanguage(lang)} aria-pressed={language === lang}>
              {lang}
            </button>
          ))}
        </nav>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow"><span className="gold-dot" />{t.eyebrow}</p>
          <h1>{t.headlineA}<br /><em>{t.headlineB}</em></h1>
          <p className="hero-intro">{t.intro}</p>
          <a className="primary-link" href="#presentations">{t.choose}<span aria-hidden="true">↘</span></a>
          <div className="hero-footnote">RĪGA · LATVIJA</div>
        </div>
        <div className="hero-photo" role="img" aria-label="Upīša Pasāžas arhitektūra" />
      </section>

      <section className="presentations" id="presentations">
        <div className="section-heading">
          <p className="eyebrow">LL & K <span className="eyebrow-divider">/</span> {language === 'LV' ? 'PREZENTĀCIJAS' : language === 'ENG' ? 'PRESENTATIONS' : 'ПРЕЗЕНТАЦИИ'}</p>
          <h2>{t.choose}<span className="gold-period">.</span></h2>
        </div>
        <div className="card-grid">
          {t.cards.map((card) => (
            <article className="presentation-card" key={card.number}>
              <div className="card-topline"><span>{card.number}</span><span className="card-arrow" aria-hidden="true">↗</span></div>
              <div className="card-rule" />
              <h3>{card.title}</h3>
              <p>{card.description}</p>
              <a className="card-action" href={`${pdfs[language]}#page=${card.page}`} target="_blank" rel="noreferrer">
                {card.action}<span aria-hidden="true"> →</span>
              </a>
            </article>
          ))}
        </div>
        <div className="download-row">
          <div><span className="download-label">PDF · {language}</span><p>{language === 'LV' ? 'Visa prezentācija vienā failā.' : language === 'ENG' ? 'The complete presentation in one file.' : 'Вся презентация в одном файле.'}</p></div>
          <a className="download-button" href={pdfs[language]} download>{t.download}<span aria-hidden="true"> ↓</span></a>
        </div>
      </section>

      <footer className="footer">
        <div className="footer-brand">LL <i>&</i> K</div>
        <p>{t.footer}</p>
        <a href="mailto:info@upisapasaza.lv">{t.contact} ↗</a>
      </footer>
    </main>
  );
}
